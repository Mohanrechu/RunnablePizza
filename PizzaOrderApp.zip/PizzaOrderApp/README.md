# Pizza Order App (Java / Android)

A simple, fully offline pizza-ordering Android app written in Java.

## Features
- Browse a pizza menu (name, description, category, price) in a scrollable list
- Tap a pizza to open a detail screen: choose size (Small/Medium/Large) and quantity
- Quick "ADD" button on the list to add the default size straight to the cart
- Cart screen: adjust quantities, remove items, live subtotal/tax/delivery/total
- Checkout screen: name, phone, address, payment method (COD / Card / UPI)
- Order confirmation screen with a generated order ID and ETA

## How to open
1. Install [Android Studio](https://developer.android.com/studio) (Hedgehog or newer recommended).
2. Choose **Open** and select the `PizzaOrderApp` folder (the one containing `settings.gradle`).
3. Let Gradle sync (it will download the AndroidX/Material dependencies).
4. Run on an emulator or device — `minSdk` is 24 (Android 7.0+).

## Project structure
```
app/src/main/java/com/example/pizzaorder/
  Pizza.java                  - pizza data model
  CartItem.java                - one line item in the cart (pizza + size + qty)
  Cart.java                    - in-memory singleton cart (subtotal/tax/total logic)
  PizzaMenu.java                - static list of pizzas (swap for a real API later)
  PizzaAdapter.java / CartAdapter.java  - RecyclerView adapters
  MainActivity.java             - menu screen
  PizzaDetailActivity.java      - size/quantity picker
  CartActivity.java             - cart + order summary
  CheckoutActivity.java         - delivery details + payment method
  OrderConfirmationActivity.java - success screen

app/src/main/res/
  layout/   - all screen and list-item XML layouts
  values/   - colors, strings, theme
  drawable/ - vector pizza icon used as a placeholder image
```

## Notes / where to extend this
- **Menu data** currently lives in `PizzaMenu.java`. Point it at a REST API
  (e.g. with Retrofit) to load pizzas dynamically instead.
- **Cart** is in-memory only (`Cart.java` singleton), so it resets if the app
  process is killed. Swap in a Room database or SharedPreferences/JSON file
  if the cart needs to survive app restarts.
- **Images** use a simple vector-drawable pizza icon as a placeholder for
  every item — drop real photos into `res/drawable` and reference them from
  `PizzaMenu.java` (`imageResId` field) for a more polished look.
- **Payment** is just a UI selection; no payment gateway is wired up.
