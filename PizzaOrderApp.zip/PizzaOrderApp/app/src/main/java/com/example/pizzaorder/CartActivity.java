package com.example.pizzaorder;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Locale;

public class CartActivity extends AppCompatActivity implements CartAdapter.OnCartChangeListener {

    private RecyclerView recyclerView;
    private View textEmptyCart;
    private View layoutSummary;
    private TextView textSubtotal, textDeliveryFee, textTax, textTotal;
    private CartAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.recyclerViewCart);
        textEmptyCart = findViewById(R.id.textEmptyCart);
        layoutSummary = findViewById(R.id.layoutSummary);
        textSubtotal = findViewById(R.id.textSubtotal);
        textDeliveryFee = findViewById(R.id.textDeliveryFee);
        textTax = findViewById(R.id.textTax);
        textTotal = findViewById(R.id.textTotal);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CartAdapter(Cart.getInstance().getItems(), this);
        recyclerView.setAdapter(adapter);

        findViewById(R.id.buttonCheckout).setOnClickListener(v -> {
            if (Cart.getInstance().getItems().isEmpty()) {
                Toast.makeText(this, "Your cart is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(this, CheckoutActivity.class));
        });

        refreshUI();
    }

    @Override
    public void onCartChanged() {
        adapter.notifyDataSetChanged();
        refreshUI();
    }

    private void refreshUI() {
        Cart cart = Cart.getInstance();
        boolean empty = cart.getItems().isEmpty();

        recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
        textEmptyCart.setVisibility(empty ? View.VISIBLE : View.GONE);
        layoutSummary.setVisibility(empty ? View.GONE : View.VISIBLE);

        textSubtotal.setText(String.format(Locale.getDefault(), "₹%.0f", cart.getSubtotal()));
        textDeliveryFee.setText(String.format(Locale.getDefault(), "₹%.0f", cart.getDeliveryFee()));
        textTax.setText(String.format(Locale.getDefault(), "₹%.0f", cart.getTax()));
        textTotal.setText(String.format(Locale.getDefault(), "₹%.0f", cart.getTotal()));
    }
}
