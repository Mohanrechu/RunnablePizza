package com.example.pizzaorder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity implements PizzaAdapter.OnPizzaClickListener {

    private ExtendedFloatingActionButton fabCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Pizza Order");
        setSupportActionBar(toolbar);

        List<Pizza> pizzas = PizzaMenu.getAllPizzas();

        RecyclerView recyclerView = findViewById(R.id.recyclerViewPizzas);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new PizzaAdapter(pizzas, this));

        fabCart = findViewById(R.id.fabCart);
        fabCart.setOnClickListener(v -> startActivity(new Intent(this, CartActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartFab();
    }

    private void updateCartFab() {
        int count = Cart.getInstance().getItemCount();
        fabCart.setText("View Cart (" + count + ")");
    }

    @Override
    public void onPizzaClick(Pizza pizza) {
        Intent intent = new Intent(this, PizzaDetailActivity.class);
        intent.putExtra(PizzaDetailActivity.EXTRA_PIZZA, pizza);
        startActivity(intent);
    }

    @Override
    public void onAddClick(Pizza pizza) {
        Cart.getInstance().addItem(pizza, "Small", 1);
        Toast.makeText(this, pizza.getName() + " added to cart", Toast.LENGTH_SHORT).show();
        updateCartFab();
    }
}
