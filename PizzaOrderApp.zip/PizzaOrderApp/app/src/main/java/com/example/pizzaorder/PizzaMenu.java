package com.example.pizzaorder;

import java.util.ArrayList;
import java.util.List;

/**
 * Local menu data source. Replace with a network/Retrofit call to a real
 * backend when one is available; the rest of the app only depends on
 * getAllPizzas() returning a List<Pizza>.
 */
public class PizzaMenu {

    public static List<Pizza> getAllPizzas() {
        List<Pizza> list = new ArrayList<>();

        list.add(new Pizza(1, "Margherita",
                "Classic delight with 100% real mozzarella cheese",
                199, 349, 499, "Veg", R.drawable.ic_pizza_placeholder));

        list.add(new Pizza(2, "Farmhouse",
                "Delightful combination of onion, capsicum, tomato & mushroom",
                249, 399, 549, "Veg", R.drawable.ic_pizza_placeholder));

        list.add(new Pizza(3, "Peppy Paneer",
                "Paneer with peppy tangy tomato, capsicum & red paprika",
                269, 419, 569, "Veg", R.drawable.ic_pizza_placeholder));

        list.add(new Pizza(4, "Chicken Dominator",
                "Loaded with double pepper barbecue chicken & grilled chicken",
                329, 479, 649, "Non-Veg", R.drawable.ic_pizza_placeholder));

        list.add(new Pizza(5, "Pepper Barbecue Chicken",
                "Barbecue chicken with pepper barbecue sauce",
                299, 449, 599, "Non-Veg", R.drawable.ic_pizza_placeholder));

        list.add(new Pizza(6, "Chicken Sausage",
                "Chunky chicken sausage delight with cheese",
                289, 439, 589, "Non-Veg", R.drawable.ic_pizza_placeholder));

        list.add(new Pizza(7, "Veggie Paradise",
                "Loaded with black olives, capsicum, onion, corn & tomato",
                259, 409, 559, "Veg", R.drawable.ic_pizza_placeholder));

        list.add(new Pizza(8, "Non-Veg Supreme",
                "Loaded with chicken sausage, chicken tikka, keema & more",
                349, 499, 679, "Non-Veg", R.drawable.ic_pizza_placeholder));

        return list;
    }
}
