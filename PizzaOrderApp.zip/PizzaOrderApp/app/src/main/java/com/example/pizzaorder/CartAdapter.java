package com.example.pizzaorder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    public interface OnCartChangeListener {
        void onCartChanged();
    }

    private final List<CartItem> items;
    private final OnCartChangeListener listener;

    public CartAdapter(List<CartItem> items, OnCartChangeListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = items.get(position);
        holder.textName.setText(item.getPizza().getName());
        holder.textSize.setText(String.format(Locale.getDefault(), "%s · ₹%.0f",
                item.getSize(), item.getUnitPrice()));
        holder.textQuantity.setText(String.valueOf(item.getQuantity()));

        holder.buttonMinus.setOnClickListener(v -> {
            Cart.getInstance().updateQuantity(item, item.getQuantity() - 1);
            listener.onCartChanged();
        });

        holder.buttonPlus.setOnClickListener(v -> {
            Cart.getInstance().updateQuantity(item, item.getQuantity() + 1);
            listener.onCartChanged();
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView textName, textSize, textQuantity;
        View buttonMinus, buttonPlus;

        CartViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textName);
            textSize = itemView.findViewById(R.id.textSize);
            textQuantity = itemView.findViewById(R.id.textQuantity);
            buttonMinus = itemView.findViewById(R.id.buttonMinus);
            buttonPlus = itemView.findViewById(R.id.buttonPlus);
        }
    }
}
