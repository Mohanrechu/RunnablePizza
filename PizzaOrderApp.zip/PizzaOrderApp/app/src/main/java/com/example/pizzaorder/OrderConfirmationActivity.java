package com.example.pizzaorder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class OrderConfirmationActivity extends AppCompatActivity {

    public static final String EXTRA_ORDER_ID = "extra_order_id";
    public static final String EXTRA_TOTAL = "extra_total";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_confirmation);

        String orderId = getIntent().getStringExtra(EXTRA_ORDER_ID);
        double total = getIntent().getDoubleExtra(EXTRA_TOTAL, 0);

        TextView textOrderId = findViewById(R.id.textOrderId);
        TextView textEta = findViewById(R.id.textEta);
        TextView textOrderTotalFinal = findViewById(R.id.textOrderTotalFinal);

        textOrderId.setText("Order #" + orderId);
        textEta.setText("Estimated delivery: 35-40 mins");
        textOrderTotalFinal.setText(String.format(Locale.getDefault(), "Total Paid: ₹%.0f", total));

        findViewById(R.id.buttonBackToMenu).setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }
}
