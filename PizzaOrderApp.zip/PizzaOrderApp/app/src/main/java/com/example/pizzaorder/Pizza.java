package com.example.pizzaorder;

import java.io.Serializable;

public class Pizza implements Serializable {

    private int id;
    private String name;
    private String description;
    private double priceSmall;
    private double priceMedium;
    private double priceLarge;
    private String category; // Veg / Non-Veg
    private int imageResId;

    public Pizza(int id, String name, String description, double priceSmall,
                 double priceMedium, double priceLarge, String category, int imageResId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.priceSmall = priceSmall;
        this.priceMedium = priceMedium;
        this.priceLarge = priceLarge;
        this.category = category;
        this.imageResId = imageResId;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPriceForSize(String size) {
        switch (size) {
            case "Medium":
                return priceMedium;
            case "Large":
                return priceLarge;
            case "Small":
            default:
                return priceSmall;
        }
    }

    public double getPriceSmall() {
        return priceSmall;
    }

    public String getCategory() {
        return category;
    }

    public int getImageResId() {
        return imageResId;
    }
}
