package com.example.pizzaorder;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Locale;
import java.util.Random;

public class CheckoutActivity extends AppCompatActivity {

    private TextInputEditText editName, editPhone, editAddress;
    private RadioGroup radioGroupPayment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        editName = findViewById(R.id.editName);
        editPhone = findViewById(R.id.editPhone);
        editAddress = findViewById(R.id.editAddress);
        radioGroupPayment = findViewById(R.id.radioGroupPayment);

        TextView textOrderTotal = findViewById(R.id.textOrderTotal);
        double total = Cart.getInstance().getTotal();
        textOrderTotal.setText(String.format(Locale.getDefault(), "Order Total: ₹%.0f", total));

        findViewById(R.id.buttonPlaceOrder).setOnClickListener(v -> placeOrder());
    }

    private void placeOrder() {
        String name = safeText(editName);
        String phone = safeText(editPhone);
        String address = safeText(editAddress);

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(address)) {
            Toast.makeText(this, "Please fill in all delivery details", Toast.LENGTH_SHORT).show();
            return;
        }
        if (phone.length() < 7) {
            Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        String orderId = "PZ" + (10000 + new Random().nextInt(89999));
        double total = Cart.getInstance().getTotal();

        Intent intent = new Intent(this, OrderConfirmationActivity.class);
        intent.putExtra(OrderConfirmationActivity.EXTRA_ORDER_ID, orderId);
        intent.putExtra(OrderConfirmationActivity.EXTRA_TOTAL, total);

        Cart.getInstance().clear();
        startActivity(intent);
        finish();
    }

    private String safeText(TextInputEditText editText) {
        return editText.getText() == null ? "" : editText.getText().toString().trim();
    }
}
