package com.example.pizzaorder;

import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.button.MaterialButton;

import java.util.Locale;

public class PizzaDetailActivity extends AppCompatActivity {

    public static final String EXTRA_PIZZA = "extra_pizza";

    private Pizza pizza;
    private String selectedSize = "Small";
    private int quantity = 1;

    private TextView textQuantity;
    private MaterialButton buttonAddToCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_detail);

        pizza = (Pizza) getIntent().getSerializableExtra(EXTRA_PIZZA);
        if (pizza == null) {
            finish();
            return;
        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        TextView textName = findViewById(R.id.textName);
        TextView textCategory = findViewById(R.id.textCategory);
        TextView textDescription = findViewById(R.id.textDescription);
        textQuantity = findViewById(R.id.textQuantity);
        buttonAddToCart = findViewById(R.id.buttonAddToCart);

        textName.setText(pizza.getName());
        textCategory.setText(pizza.getCategory().toUpperCase(Locale.getDefault()));
        textDescription.setText(pizza.getDescription());
        findViewById(R.id.imagePizza); // layout reference; drawable already set in XML

        RadioGroup radioGroupSize = findViewById(R.id.radioGroupSize);
        radioGroupSize.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioSmall) {
                selectedSize = "Small";
            } else if (checkedId == R.id.radioMedium) {
                selectedSize = "Medium";
            } else if (checkedId == R.id.radioLarge) {
                selectedSize = "Large";
            }
            updateAddToCartLabel();
        });

        findViewById(R.id.buttonMinus).setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                textQuantity.setText(String.valueOf(quantity));
                updateAddToCartLabel();
            }
        });

        findViewById(R.id.buttonPlus).setOnClickListener(v -> {
            quantity++;
            textQuantity.setText(String.valueOf(quantity));
            updateAddToCartLabel();
        });

        buttonAddToCart.setOnClickListener(v -> {
            Cart.getInstance().addItem(pizza, selectedSize, quantity);
            Toast.makeText(this,
                    quantity + " x " + pizza.getName() + " (" + selectedSize + ") added to cart",
                    Toast.LENGTH_SHORT).show();
            finish();
        });

        updateAddToCartLabel();
    }

    private void updateAddToCartLabel() {
        double price = pizza.getPriceForSize(selectedSize) * quantity;
        buttonAddToCart.setText(String.format(Locale.getDefault(), "Add to Cart · ₹%.0f", price));
    }
}
