package com.example.pizzaorder;

import java.io.Serializable;

public class CartItem implements Serializable {

    private Pizza pizza;
    private String size;
    private int quantity;

    public CartItem(Pizza pizza, String size, int quantity) {
        this.pizza = pizza;
        this.size = size;
        this.quantity = quantity;
    }

    public Pizza getPizza() {
        return pizza;
    }

    public String getSize() {
        return size;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return pizza.getPriceForSize(size);
    }

    public double getTotalPrice() {
        return getUnitPrice() * quantity;
    }

    /**
     * Two cart items are considered the "same line" if same pizza id and same size,
     * so adding the same pizza+size again just increases quantity.
     */
    public boolean matches(Pizza otherPizza, String otherSize) {
        return this.pizza.getId() == otherPizza.getId() && this.size.equals(otherSize);
    }
}
