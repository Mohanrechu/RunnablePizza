package com.example.pizzaorder;

import java.util.ArrayList;
import java.util.List;

/**
 * Simple in-memory singleton cart. Good enough for a local demo app;
 * swap for a persisted Room database if orders need to survive app kill.
 */
public class Cart {

    private static Cart instance;
    private final List<CartItem> items = new ArrayList<>();

    public static final double DELIVERY_FEE = 40.0;
    public static final double TAX_RATE = 0.05;

    private Cart() {
    }

    public static Cart getInstance() {
        if (instance == null) {
            instance = new Cart();
        }
        return instance;
    }

    public void addItem(Pizza pizza, String size, int quantity) {
        for (CartItem item : items) {
            if (item.matches(pizza, size)) {
                item.setQuantity(item.getQuantity() + quantity);
                return;
            }
        }
        items.add(new CartItem(pizza, size, quantity));
    }

    public void removeItem(CartItem item) {
        items.remove(item);
    }

    public void updateQuantity(CartItem item, int quantity) {
        if (quantity <= 0) {
            removeItem(item);
        } else {
            item.setQuantity(quantity);
        }
    }

    public List<CartItem> getItems() {
        return items;
    }

    public int getItemCount() {
        int count = 0;
        for (CartItem item : items) {
            count += item.getQuantity();
        }
        return count;
    }

    public double getSubtotal() {
        double subtotal = 0;
        for (CartItem item : items) {
            subtotal += item.getTotalPrice();
        }
        return subtotal;
    }

    public double getTax() {
        return getSubtotal() * TAX_RATE;
    }

    public double getDeliveryFee() {
        return items.isEmpty() ? 0 : DELIVERY_FEE;
    }

    public double getTotal() {
        return getSubtotal() + getTax() + getDeliveryFee();
    }

    public void clear() {
        items.clear();
    }
}
