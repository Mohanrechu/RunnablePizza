package com.example.pizzaorder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class PizzaAdapter extends RecyclerView.Adapter<PizzaAdapter.PizzaViewHolder> {

    public interface OnPizzaClickListener {
        void onPizzaClick(Pizza pizza);

        void onAddClick(Pizza pizza);
    }

    private final List<Pizza> pizzas;
    private final OnPizzaClickListener listener;

    public PizzaAdapter(List<Pizza> pizzas, OnPizzaClickListener listener) {
        this.pizzas = pizzas;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PizzaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pizza, parent, false);
        return new PizzaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PizzaViewHolder holder, int position) {
        Pizza pizza = pizzas.get(position);
        holder.textName.setText(pizza.getName());
        holder.textDescription.setText(pizza.getDescription());
        holder.textPrice.setText(String.format(Locale.getDefault(), "From ₹%.0f", pizza.getPriceSmall()));
        holder.imagePizza.setImageResource(pizza.getImageResId());

        holder.itemView.setOnClickListener(v -> listener.onPizzaClick(pizza));
        holder.buttonAdd.setOnClickListener(v -> listener.onAddClick(pizza));
    }

    @Override
    public int getItemCount() {
        return pizzas.size();
    }

    static class PizzaViewHolder extends RecyclerView.ViewHolder {
        ImageView imagePizza;
        TextView textName, textDescription, textPrice;
        View buttonAdd;

        PizzaViewHolder(@NonNull View itemView) {
            super(itemView);
            imagePizza = itemView.findViewById(R.id.imagePizza);
            textName = itemView.findViewById(R.id.textName);
            textDescription = itemView.findViewById(R.id.textDescription);
            textPrice = itemView.findViewById(R.id.textPrice);
            buttonAdd = itemView.findViewById(R.id.buttonAdd);
        }
    }
}
